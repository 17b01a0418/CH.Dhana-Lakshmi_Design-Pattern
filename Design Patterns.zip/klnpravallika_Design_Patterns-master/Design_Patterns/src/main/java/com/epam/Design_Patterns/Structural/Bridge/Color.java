package com.epam.Design_Patterns.Structural.Bridge;

public interface Color {

	public void applyColor();
}