package com.epam.Design_Patterns.Behavioral.State;

public interface State {

	public void doAction();
}