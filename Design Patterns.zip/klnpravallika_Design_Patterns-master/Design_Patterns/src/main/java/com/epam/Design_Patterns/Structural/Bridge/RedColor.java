package com.epam.Design_Patterns.Structural.Bridge;

public class RedColor implements Color{

	public void applyColor(){
		System.out.println("red.");
	}
}